import 'package:flutter/material.dart';
import 'package:flutter_prob/widget/first_widget.dart';
import 'package:flutter_prob/widget/second_widget.dart';

class HomeScreen extends StatelessWidget {
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Page Routing Problem'
        ),
      ),
      body: Column(
        children: <Widget>[
          FirstWidget(), 
          SecondWidget(),
        ],
      ),
    );
  }
}