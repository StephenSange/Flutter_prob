import 'package:flutter/material.dart';
import 'package:flutter_prob/models/first_list_view.dart';

class SecondWidget extends StatelessWidget {
  
  final String title;
  final String imageUrl;

  SecondWidget(this.title, this.imageUrl);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 300,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: display.length,
        itemBuilder: (context, index) {
          return Container(
            width: 210,
            margin: EdgeInsets.all(10),
            child: Stack(
              children: <Widget>[
                Positioned(
                  bottom: 15,
                  child: Container(
                 
                    width: 200,
                    height: 70,
                    decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(10)
                        ),
                  ),
                ),
                SizedBox(height: 10),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(10)
                  ),
                  child: Stack(
                    children: <Widget>[
                      Image(
                        height: 200,
                        width: 200,
                        image: AssetImage(imageUrl),
                      )
                    ],
                  ),
                )
              ],
            ),
          );
        },
      ),
    );
  }
}
