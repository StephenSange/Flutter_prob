import 'package:flutter/material.dart';
import 'package:flutter_prob/models/first_list_view.dart';

class FirstWidget extends StatelessWidget {
  // When i pass title and imageUrl here, automatically i an error in the 
  // homescreen as the Top Notch widget is requesting for same to be passed
  // I can use for instance, display[index].imageUrl or display[index].title 
  // without passing (final String title) but as my app gets bigger, i can't
  // For eg: i was trying to build an app wwhere i had to connect the one ID 
  // to a parent ID so i had to use (.where) but because of the error i am 
  // in the homescreen, i could not continue. I am facing a similar challenge 
  // when using Named Routes.
  
  final String title;
  final String imageUrl;

  FirstWidget(this.title, this.imageUrl);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 300,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: display.length,
        itemBuilder: (context, index) {
          return Container(
            width: 210,
            margin: EdgeInsets.all(10),
            child: Stack(
              children: <Widget>[
                Positioned(
                  bottom: 15,
                  child: Container(
                 
                    width: 200,
                    height: 70,
                    decoration: BoxDecoration(
                        color: Colors.blue,
                        borderRadius: BorderRadius.circular(10)
                        ),
                  ),
                ),
                SizedBox(height: 10),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(10)
                  ),
                  child: Stack(
                    children: <Widget>[
                      Image(
                        height: 200,
                        width: 200,
                        image: AssetImage(imageUrl),
                      )
                    ],
                  ),
                )
              ],
            ),
          );
        },
      ),
    );
  }
}
