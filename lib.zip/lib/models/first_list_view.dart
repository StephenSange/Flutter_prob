class Display {
  final String id;
  final String title;
  final String imageUrl;

  Display({
    this.id,
    this.title,
    this.imageUrl,
  });
}


final List<Display> display = [
  Display(
    id: 'c1',
    title: 'sark',
    imageUrl: 'assets/images/alpha.jpg'
  ),
  Display(
    id: 'c2',
    title: 'Karl',
    imageUrl: 'assets/images/kaligraph.jpg'
  ),
  Display(
    id: 'c3',
    title: 'SarkCess',
    imageUrl: 'assets/images/sarkodie.jpg'
  ),
  Display(
    id: 'c4',
    title: 'Sala',
    imageUrl: 'assets/images/senegal.jpg'
  ),
];